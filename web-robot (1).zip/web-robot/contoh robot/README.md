Contoh Tampilan Web Sekolah
===========================

Contoh Web Sekolah Vroh, langsung akses di mari

[http://novay.github.io/contoh-web-sekolah](http://novay.github.io/contoh-web-sekolah)

Beberapa konten belum terisi... Pokoknya gitulah... Ngahahaha....


###Credit

- SMK Negeri 1 Berau to be my victims,
- Beberapa Website-website SMA, SMK, SMP se Indonesia. Maaf bila ada masalah.
- 1st Bootstrap for make it looking goods.
- And so many more, and many more. Well i add it later.
